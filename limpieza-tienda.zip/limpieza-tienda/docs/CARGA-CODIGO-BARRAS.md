# 📷 Carga de productos con código de barras — Aroma a Limpio

Funcionalidad para cargar e inventariar productos escaneando el **código de
barras físico** y asignando fotografías con **arrastrar y soltar (Drag & Drop)**. Hay dos formas de escanear:

1. **Lector USB o Bluetooth** — funciona como un teclado: escribe el número y
   envía un **Enter** al final.
2. **Cámara del celular** — botón **"📷 Escanear con la cámara"** que abre la
   cámara del teléfono y lee el código sin necesidad de lector externo.

---

## 🖼️ Novedad: Carga de fotos con Drag & Drop y Portapapeles (Ctrl+V)

La sección de fotografía ahora cuenta con una **Dropzone moderna e interactiva**:

- 🖱️ **Arrastrar y soltar (Drag & Drop)**: Arrastrá fotos directamente desde tu explorador de archivos (Windows / Mac / Linux / móvil) a la zona delimitada.
- 📁 **Explorador tradicional**: Hacé clic en cualquier parte de la zona o en *"📁 Elegir foto..."* para abrir el diálogo estándar.
- 📋 **Pegar desde el portapapeles (`Ctrl + V` / `Cmd + V`)**: Podés hacer una captura de pantalla, copiar una imagen de internet y pegarla directamente con el teclado sin necesidad de guardarla primero.
- 🌐 **Arrastre desde la web**: Podés arrastrar imágenes directamente desde otra pestaña de tu navegador a la pantalla.
- ⚡ **Compresión y optimización automática**: Antes de enviarse al servidor, la foto se redimensiona en el navegador a máximo 1000 px en formato JPEG optimizado. Esto ahorra ancho de banda y espacio en la base de datos sin perder calidad visual.
- 👁️ **Vista previa completa con detalles**: Muestra miniatura, nombre del archivo, tamaño en KB/MB y botones para *Cambiar* o *Quitar* la foto antes de guardar.
- 🔁 **Detección de fotos existentes**: Si escaneás un producto que ya existe en el catálogo, su foto actual se precarga automáticamente en la vista previa.

---

## 📱 Cómo escanear y cargar con el celular (paso a paso)

1. Abrí la tienda en el teléfono (la URL de Render, ej.
   `https://tu-servicio.onrender.com/`).
2. Entrá al panel: `/admin.html` → ingresá usuario y clave → botón
   **"📷 Carga con lector"**.
3. Tocá **"📷 Escanear con la cámara"** (o usá el lector USB/Bluetooth).
4. El navegador te va a pedir **permiso para usar la cámara** → tocá *Permitir*.
5. Apuntá la cámara al código de barras (cámara trasera, buena luz, a ~15–20 cm).
6. Al leerlo, la pantalla **pita como la caja de un supermercado** y te avisa:
   - 🆕 **Código nuevo** → pitido de OK y cartel verde: completás nombre, precio,
     stock, descripción, foto (arrastrando o tocando para sacar foto) y categoría.
   - ⛔ **YA CARGADO** → pitido de error y cartel rojo grande con el nombre y el
     stock actual. Si es reposición, ponés la cantidad y tocás **"➕ Sumar stock"**.
7. Tocá **"💾 Guardar producto"** (o "➕ Sumar stock") y listo.

> ⚠️ **La cámara requiere HTTPS.** En Render el sitio ya es HTTPS, así que
> funciona directo. En local también funciona con `http://localhost` (los
> navegadores lo consideran seguro). Los códigos soportados incluyen
> **EAN-13, EAN-8, UPC-A, UPC-E, Code 128, Code 39, ITF, Codabar y QR**.

---

## 🧠 Cómo funciona

1. El operador escanea el código (lector que escribe + Enter, o cámara).
2. **La página NO se recarga**: al recibir el código se consulta si ya existe y
   el foco pasa automáticamente al campo **Nombre**.
   - Si el código **ya existe** → cartel rojo **"⛔ YA CARGADO"** (con pitido),
     se precargan nombre, precio, descripción, foto existente y categoría; el campo stock queda
     para **sumar** reposición.
   - Si es **nuevo** → pitido de OK y cartel verde; formulario limpio.
3. Se completan nombre, precio, stock, descripción, foto y categoría.
4. Al guardar:
   - **Código nuevo** → crea el producto (con una variante "Unidad").
   - **Código existente** → actualiza datos y **suma** el stock escaneado.
   - La foto se guarda **directamente en la base de datos** (tabla `imagenes`) y
     en el producto queda la ruta `/api/imagen/<id>`. Así la foto **sobrevive a
     los redeploys** (el disco del servidor de Render es temporal).

---

## 🔢 Normalización de códigos (12 vs 13 dígitos)

Algunos lectores/cámaras devuelven el **UPC-A** (12 dígitos) y otros el
**EAN-13** (13 dígitos) para el **mismo** producto. Para que dos celulares
distintos no carguen el mismo producto dos veces:

- Si el código leído tiene **12 dígitos**, se le antepone un `0` y se guarda
  como EAN-13. Ej.: `779123456789` → `0779123456789`.
- La búsqueda y el guardado normalizan igual, así que ambos formatos caen en el
  **mismo** producto.

> 💡 Si un paquete tiene **dos códigos distintos** (uno grande EAN-13 y uno
> chico UPC-A), usá siempre el **grande** (EAN-13). Con la normalización, el
> chico también termina apuntando al mismo producto.

---

## 🗑️ Empezar de cero (vaciar el catálogo)

El catálogo arranca **vacío de productos** (solo quedan las 4 categorías). Para
borrar todo lo cargado y volver a empezar:

1. Entrá al panel `/admin.html`.
2. Pestaña **📦 Productos** → botón **"🗑️ Vaciar productos"**.
3. Confirmá. Se borran todos los productos (y sus variantes); las categorías se
   conservan.

> Endpoint: `DELETE /api/admin/productos` (requiere token). Devuelve
> `{"eliminados": N, "mensaje": "…"}`.

---

## 🗄️ Base de datos

Se agregó la columna `codigo_barras` a la tabla `productos` con un **índice
ÚNICO** (impide duplicar el mismo código y habilita el "upsert").

- **Base nueva (desde cero):** `database/schema.sql` ya incluye la columna y la tabla `imagenes`.
- **Base existente:** ejecutar `database/migracion_codigo_barras.sql`
  (incluye la variante para MySQL y para PostgreSQL).

> El precio y el stock viven en la tabla `variantes` (así el producto escaneado
> aparece directamente en el catálogo de la tienda). Al cargar se crea/actualiza
> una variante de presentación "Unidad" con el precio y stock escaneados.

---

## ⚙️ Backend (Spring Boot + PostgreSQL)

Archivos:

| Archivo | Qué hace |
| --- | --- |
| `model/Producto.java` | Campo `codigoBarras` |
| `repository/ProductoRepository.java` | `findByCodigoBarras(...)` |
| `service/ImageStorageService.java` | Guarda la foto en la base (tabla `imagenes`) y borra la anterior |
| `service/CargaProductoService.java` | Lógica de upsert (crear o actualizar + sumar stock) |
| `dto/CargaProductoResponse.java` | Respuesta: creado/actualizado, stock total, imagen |
| `controller/AdminController.java` | Endpoints `POST /api/admin/carga`, `POST /api/admin/imagen` y `GET /api/admin/productos/barcode/{codigo}` |
| `model/Imagen.java` + `repository/ImagenRepository.java` | Entidad/repo de la tabla `imagenes` (fotos en bytea) |
| `controller/ImagenController.java` | Sirve `GET /api/imagen/{id}` (público, con cache) |
| `application.yml` | Límites de subida de fotos |

### Endpoints (requieren el token del panel: header `X-Admin-Token`)

**`POST /api/admin/carga`** — `multipart/form-data`

| Campo | Tipo | Requerido | Descripción |
| --- | --- | --- | --- |
| `codigoBarras` | text | sí | Lo que envía el lector |
| `nombre` | text | sí | Nombre del producto |
| `precio` | number | sí | Decimal (ej. `2150.50`) |
| `stock` | int | sí | Si el código existe, se **suma** |
| `categoriaId` | long | sí | Categoría del producto |
| `descripcion` | text | no | Detalle |
| `imagen` | file | no | `image/*` (jpg/png/webp/gif) |

**`POST /api/admin/imagen`** — `multipart/form-data` (subida individual)

**`GET /api/admin/productos/barcode/{codigo}`** → devuelve el producto o `404`
si no existe (lo usa la pantalla para precargar datos).

**`DELETE /api/admin/productos`** → vacía el catálogo completo (productos +
variantes). Devuelve `{"eliminados": N, "mensaje": "…"}`.

---

## 🖥️ Frontend

- **`static/carga.html`** — pantalla de carga de artículos con Drag & Drop y escáner por cámara.
- **`static/js/carga.js`** — lógica del lector, Drag & Drop, portapapeles, compresión y envío con `FormData`.
- **`static/admin.html`** y **`static/js/admin.js`** — panel de administración con soporte de Drag & Drop en el modal de productos.
- **`static/css/admin.css`** — estilos de la Dropzone interactiva.
- **`static/js/html5-qrcode.min.js`** — librería de escaneo por cámara (servida localmente).

---

## 🚀 Paso a paso para integrarlo en tu proyecto

1. **Subí los archivos modificados a tu repositorio en GitHub**:
   - `backend/src/main/resources/static/carga.html`
   - `backend/src/main/resources/static/js/carga.js`
   - `backend/src/main/resources/static/admin.html`
   - `backend/src/main/resources/static/js/admin.js`
   - `backend/src/main/resources/static/css/admin.css`
   - `backend/src/main/java/com/limpieza/tienda/controller/AdminController.java`
   - `backend/src/main/java/com/limpieza/tienda/service/AdminService.java`

2. **Redeploy** en Render (el Dockerfile compila todo automáticamente).

3. **Probá**: entrá al panel (`/admin.html`) → botón **"📷 Carga con lector"** → arrastrá cualquier imagen o pegala con `Ctrl+V`.
