package com.limpieza.tienda.controller;

import com.limpieza.tienda.dto.CargaProductoResponse;
import com.limpieza.tienda.dto.CategoriaDto;
import com.limpieza.tienda.dto.CategoriaRequest;
import com.limpieza.tienda.dto.LoginRequest;
import com.limpieza.tienda.dto.PedidoEstadoRequest;
import com.limpieza.tienda.dto.PedidoResponse;
import com.limpieza.tienda.dto.ProductoDto;
import com.limpieza.tienda.dto.ProductoUpsertRequest;
import com.limpieza.tienda.service.AdminService;
import com.limpieza.tienda.service.AuthService;
import com.limpieza.tienda.service.CargaProductoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * Panel de administración (protegido por {@code AdminAuthInterceptor}).
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;
    private final AuthService authService;
    private final CargaProductoService cargaProductoService;

    public AdminController(AdminService adminService, AuthService authService,
                           CargaProductoService cargaProductoService) {
        this.adminService = adminService;
        this.authService = authService;
        this.cargaProductoService = cargaProductoService;
    }

    // ---------------- Auth ----------------

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody LoginRequest request) {
        return Map.of("token", authService.login(request));
    }

    // ---------------- Categorías ----------------

    @GetMapping("/categorias")
    public List<CategoriaDto> categorias() {
        return adminService.listarCategorias();
    }

    @PostMapping("/categorias")
    @ResponseStatus(HttpStatus.CREATED)
    public CategoriaDto crearCategoria(@Valid @RequestBody CategoriaRequest request) {
        return adminService.crearCategoria(request);
    }

    @PutMapping("/categorias/{id}")
    public CategoriaDto actualizarCategoria(@PathVariable Long id,
                                            @Valid @RequestBody CategoriaRequest request) {
        return adminService.actualizarCategoria(id, request);
    }

    @DeleteMapping("/categorias/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminarCategoria(@PathVariable Long id) {
        adminService.eliminarCategoria(id);
    }

    // ---------------- Productos ----------------

    @GetMapping("/productos")
    public List<ProductoDto> productos() {
        return adminService.listarProductos();
    }

    @PostMapping("/productos")
    @ResponseStatus(HttpStatus.CREATED)
    public ProductoDto crearProducto(@Valid @RequestBody ProductoUpsertRequest request) {
        return adminService.crearProducto(request);
    }

    @PutMapping("/productos/{id}")
    public ProductoDto actualizarProducto(@PathVariable Long id,
                                          @Valid @RequestBody ProductoUpsertRequest request) {
        return adminService.actualizarProducto(id, request);
    }

    @DeleteMapping("/productos/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminarProducto(@PathVariable Long id) {
        adminService.eliminarProducto(id);
    }

    /** Vacía el catálogo: borra todos los productos (y sus variantes). */
    @DeleteMapping("/productos")
    public Map<String, Object> vaciarProductos() {
        long eliminados = adminService.vaciarProductos();
        return Map.of("eliminados", eliminados,
                "mensaje", "Se eliminaron " + eliminados + " productos.");
    }

    /** Subida individual de imágenes (para el modal del panel de administración). */
    @PostMapping(value = "/imagen", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, String> subirImagen(@RequestParam("imagen") MultipartFile imagen) {
        String url = adminService.subirImagen(imagen);
        return Map.of("url", url != null ? url : "");
    }

    // ---------------- Carga con lector de código de barras ----------------

    /**
     * Alta/actualización de productos desde el lector (multipart/form-data).
     * Si el código de barras ya existe, actualiza datos y SUMA stock.
     */
    @PostMapping(value = "/carga", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public CargaProductoResponse cargaProducto(
            @RequestParam("codigoBarras") String codigoBarras,
            @RequestParam("nombre") String nombre,
            @RequestParam("precio") BigDecimal precio,
            @RequestParam("stock") Integer stock,
            @RequestParam("categoriaId") Long categoriaId,
            @RequestParam(value = "descripcion", required = false) String descripcion,
            @RequestParam(value = "imagen", required = false) MultipartFile imagen) {
        return cargaProductoService.cargar(codigoBarras, nombre, precio, stock,
                categoriaId, descripcion, imagen);
    }

    /** Consulta un producto por su código de barras (para precargar el formulario). */
    @GetMapping("/productos/barcode/{codigo}")
    public ProductoDto porCodigoBarras(@PathVariable String codigo) {
        return cargaProductoService.buscarPorCodigo(codigo);
    }

    // ---------------- Pedidos ----------------

    @GetMapping("/pedidos")
    public List<PedidoResponse> pedidos() {
        return adminService.listarPedidosConItems();
    }

    @PatchMapping("/pedidos/{id}/estado")
    public PedidoResponse cambiarEstado(@PathVariable Long id,
                                        @Valid @RequestBody PedidoEstadoRequest request) {
        return PedidoResponse.from(adminService.cambiarEstado(id, request), List.of(), null);
    }
}
